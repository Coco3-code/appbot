# Robot ramasseur de dechets

| Element | Role | Dossier |
|---|---|---|
| iPhone 8 (sur le robot) | Camera + YOLO : detecte `dechet` et `obstacle`, envoie STOP / position / obstacles | `vision-iphone8/` |
| ESP32 | Cerveau : roues, errance, evitement, bras (a brancher), etat | `esp32_robot/` |
| iPhone 11 + Android | Telecommande : AUTO / MANUEL / fleches / STOP | `remote-app/` |

## 1. Modele YOLO (Google Colab)
`data.yaml` avec exactement : `names: ['dechet', 'obstacle']`
```python
!pip install ultralytics
from ultralytics import YOLO
YOLO("yolov8n.pt").train(data="data.yaml", epochs=50, imgsz=320)
YOLO("runs/detect/train/weights/best.pt").export(format="coreml", nms=True, imgsz=320)
```
Place `best.mlpackage` dans `vision-iphone8/Sources/Model/`.

## 2. Compiler (GitHub, gratuit, sans Mac)
Depot GitHub public, pousse tout ce dossier, puis onglet Actions :
- "Build iPhone 8 vision" -> artefact `vision-iphone8-ipa`
- "Build telecommande" -> `remote-ios-ipa` (iPhone 11) et `remote-android-apk` (Android)

Installe les IPA avec Sideloadly / AltStore (Apple ID gratuit, a renouveler tous les 7 jours).
L'APK s'installe directement sur Android.

## 3. ESP32
Arduino IDE, carte ESP32 : ouvre `esp32_robot/esp32_robot.ino`, adapte les broches
du L298N, televerse. Moniteur serie : 115200.

## Protocole BLE
Service `6E400001-B5A3-F393-E0A9-E50E24DCCA9E`
- `...0002` VISION (iPhone 8 -> ESP32) : `[1]` STOP, `[2,x,y,w,h]` position, `[3]` GO, `[4,masque]` obstacles
- `...0003` CMD (telecommande -> ESP32) : `A` auto, `M` manuel, `F B L R` directions, `X` stop
- `...0004` STATUS (ESP32 -> telecommande, notify) : 0 manuel, 1 errance, 2 stop dechet, 3 ramassage, 4 securite

## Securite
- En AUTO, si l'iPhone 8 n'envoie plus rien pendant 1,5 s, le robot s'arrete.
- Le bouton STOP de la telecommande coupe l'AUTO.
- Ajoute un interrupteur physique sur l'alimentation des moteurs et du futur bras.
- Camera seule = seuls les obstacles appris par YOLO sont vus. Teste d'abord a basse vitesse.
