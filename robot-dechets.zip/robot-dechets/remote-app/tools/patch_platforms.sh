#!/bin/bash
# Ajoute les permissions Bluetooth apres "flutter create" (lance depuis le dossier app/)
set -e
/usr/libexec/PlistBuddy -c "Add :NSBluetoothAlwaysUsageDescription string 'Controle du robot en Bluetooth'" ios/Runner/Info.plist
python3 - <<'PY'
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p).read()
perms = '''    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>
'''
i = s.index('<application')
open(p, 'w').write(s[:i] + perms + '    ' + s[i:])
PY
